from flask import Flask, render_template
import threading
import time
import paho.mqtt.client as mqtt
import RPi.GPIO as GPIO

# === SETTINGS ===
CHARGE_LED_PIN = 17
BUTTON_PIN = 27
LOG_FILE = "/home/pi/battery_charge_log.txt"
MQTT_BROKER = "broker.hivemq.com"
MQTT_TOPIC = "matrix/pacemaker/charge"

# === FLASK SETUP ===
app = Flask(__name__)

# === MQTT SETUP ===
mqtt_client = mqtt.Client("PacemakerPi")
mqtt_client.connect(MQTT_BROKER)

# === GPIO SETUP ===
GPIO.setmode(GPIO.BCM)
GPIO.setup(CHARGE_LED_PIN, GPIO.OUT)
GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# === BATTERY CLASS ===
class PacemakerBattery:
    def __init__(self):
        self.charge = 0
        self.connected = False

    def connect_to_matrix(self):
        self.connected = True
        self.send_mqtt("CONNECTED")

    def disconnect_from_matrix(self):
        self.connected = False
        self.send_mqtt("DISCONNECTED")

    def charge_battery(self):
        if self.connected and self.charge < 100:
            self.charge += 1
            GPIO.output(CHARGE_LED_PIN, GPIO.HIGH)
            self.send_mqtt(f"CHARGING: {self.charge}%")
        elif not self.connected:
            self.send_mqtt("HALTED")
        else:
            self.send_mqtt("FULL")
            GPIO.output(CHARGE_LED_PIN, GPIO.LOW)

    def is_fully_charged(self):
        return self.charge >= 100

    def send_mqtt(self, message):
        mqtt_client.publish(MQTT_TOPIC, message)

battery = PacemakerBattery()

# === FLASK ROUTES ===
@app.route('/')
def index():
    return render_template('index.html', charge=battery.charge, connected=battery.connected)

@app.route('/start')
def start():
    battery.connect_to_matrix()
    return render_template('index.html', charge=battery.charge, connected=battery.connected)

@app.route('/stop')
def stop():
    battery.disconnect_from_matrix()
    return render_template('index.html', charge=battery.charge, connected=battery.connected)

# === MQTT HANDLING ===
def mqtt_loop():
    while True:
        mqtt_client.loop_start()
        time.sleep(2)

def button_press_callback(channel):
    if battery.connected:
        battery.disconnect_from_matrix()
    else:
        battery.connect_to_matrix()

GPIO.add_event_detect(BUTTON_PIN, GPIO.FALLING, callback=button_press_callback, bouncetime=300)

# === STARTING THREAD AND FLASK APP ===
if __name__ == "__main__":
    mqtt_thread = threading.Thread(target=mqtt_loop)
    mqtt_thread.start()
    
    app.run(host='0.0.0.0', port=5000, debug=True)
