# Pacemaker Simulatie

Deze eenvoudige simulatie bootst het batterijbeheer van een pacemaker na.

## Functionaliteit

- De pacemaker start met 100% batterij.
- Elke dag verbruikt hij een vaste hoeveelheid energie (7%).
- Zodra de batterij onder de 45% komt, wordt hij automatisch opgeladen naar 100%.

## Gebruik

Zorg dat je Python 3 hebt geïnstalleerd.

1. Open een terminal.
2. Ga naar de map waar je `main.py` hebt opgeslagen.
3. Voer het script uit:

```bash
python main.py
