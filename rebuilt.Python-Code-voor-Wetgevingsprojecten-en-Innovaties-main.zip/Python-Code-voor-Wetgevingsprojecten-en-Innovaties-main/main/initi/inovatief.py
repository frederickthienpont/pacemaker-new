import datetime

# Definieer een class voor een Wetgevingsproject
class WetgevingsProject:
    def __init__(self, naam, type_project, start_datum, verwachte_eind_datum, kosten, status="Gepland", innovatief=False):
        """
        :param naam: Naam van het wetgevingsproject
        :param type_project: Soort project: 'Uitgevoerd', 'Hernieuwing', 'Innovatief Voorstel'
        :param start_datum: Startdatum van het project
        :param verwachte_eind_datum: Verwachte einddatum van het project
        :param kosten: Kosten van het project in euro's
        :param status: Huidige status van het project (Gepland, In uitvoering, Voltooid)
        :param innovatief: Boolean om aan te geven of het een innovatief voorstel is
        """
        self.naam = naam
        self.type_project = type_project
        self.start_datum = start_datum
        self.verwachte_eind_datum = verwachte_eind_datum
        self.kosten = kosten
        self.status = status
        self.innovatief = innovatief

    def update_status(self, nieuwe_status):
        self.status = nieuwe_status
        print(f"Status van project '{self.naam}' is bijgewerkt naar: {self.status}")

    def verleng_deadline(self, nieuwe_deadline):
        self.verwachte_eind_datum = nieuwe_deadline
        print(f"Deadline voor project '{self.naam}' is verlengd naar: {self.verwachte_eind_datum.strftime('%Y-%m-%d')}")

    def __str__(self):
        return f"Project '{self.naam}' ({self.type_project}): {self.status}, Kosten: €{self.kosten}, Startdatum: {self.start_datum.strftime('%Y-%m-%d')}, Einddatum: {self.verwachte_eind_datum.strftime('%Y-%m-%d')}, Innovatief: {self.innovatief}"

# Projectbeheer voor Wetgevingsprojecten
class WetgevingsProjectbeheer:
    def __init__(self):
        self.projecten = []

    def voeg_project_toe(self, project):
        self.projecten.append(project)
        print(f"Project '{project.naam}' toegevoegd.")

    def toon_overzicht(self):
        print("Overzicht van Wetgevingsprojecten:")
        for project in self.projecten:
            print(project)

    def zoek_project_op_status(self, status):
        print(f"Zoeken naar projecten met status: {status}")
        for project in self.projecten:
            if project.status == status:
                print(project)

    def zoek_innovatieve_projecten(self):
        print("Innovatieve Voorstellen:")
        for project in self.projecten:
            if project.innovatief:
                print(project)

# Voorbeeldgebruik van de Wetgevingsprojectbeheer
if __name__ == "__main__":
    # Maak een projectbeheer
    beheer = WetgevingsProjectbeheer()

    # Maak enkele projecten
    project1 = WetgevingsProject(
        naam="Wet herziening belastingstelsel",
        type_project="Hernieuwing",
        start_datum=datetime.datetime(2023, 6, 1),
        verwachte_eind_datum=datetime.datetime(2025, 12, 31),
        kosten=2000000,
        status="In uitvoering"
    )

    project2 = WetgevingsProject(
        naam="Innovatief voorstel voor klimaatwetgeving",
        type_project="Innovatief Voorstel",
        start_datum=datetime.datetime(2024, 1, 1),
        verwachte_eind_datum=datetime.datetime(2026, 5, 15),
        kosten=500000,
        status="Gepland",
        innovatief=True
    )

    project3 = WetgevingsProject(
        naam="Vernieuwing sociale zekerheidswetgeving",
        type_project="Hernieuwing",
        start_datum=datetime.datetime(2023, 8, 15),
        verwachte_eind_datum=datetime.datetime(2025, 6, 1),
        kosten=1500000,
        status="In uitvoering"
    )

    project4 = WetgevingsProject(
        naam="Herziening arbeidsmarktwetgeving",
        type_project="Uitgevoerd",
        start_datum=datetime.datetime(2021, 3, 1),
        verwachte_eind_datum=datetime.datetime(2022, 12, 1),
        kosten=800000,
        status="Voltooid"
    )

    # Voeg projecten toe aan het beheer
    beheer.voeg_project_toe(project1)
    beheer.voeg_project_toe(project2)
    beheer.voeg_project_toe(project3)
    beheer.voeg_project_toe(project4)

    # Toon overzicht van alle projecten
    beheer.toon_overzicht()

    # Zoek op status: "In uitvoering"
    beheer.zoek_project_op_status("In uitvoering")

    # Zoek naar innovatieve voorstellen
    beheer.zoek_innovatieve_projecten()

    # Update de status van een project
    project1.update_status("Voltooid")

    # Verleng de deadline van een project
    project2.verleng_deadline(datetime.datetime(2026, 12, 31))

    # Toon het bijgewerkte overzicht
    beheer.toon_overzicht()
