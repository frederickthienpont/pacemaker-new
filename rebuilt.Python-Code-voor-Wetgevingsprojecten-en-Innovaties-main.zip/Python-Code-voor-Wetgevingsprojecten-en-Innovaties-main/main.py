from datetime import date

class Law:
    def __init__(self, title, description, effective_date, category):
        self.title = title
        self.description = description
        self.effective_date = effective_date
        self.category = category
        self.innovations = []

    def add_innovation(self, innovation):
        self.innovations.append(innovation)

    def __str__(self):
        return f"Wet: {self.title} ({self.effective_date})\nCategorie: {self.category}\nBeschrijving: {self.description}\nInnovaties: {len(self.innovations)}"


class Innovation:
    def __init__(self, name, tech_used, summary):
        self.name = name
        self.tech_used = tech_used
        self.summary = summary

    def __str__(self):
        return f"Innovatie: {self.name}\nTechnologie: {self.tech_used}\nSamenvatting: {self.summary}"


class LegalToolkit:
    @staticmethod
    def search_by_keyword(laws, keyword):
        return [law for law in laws if keyword.lower() in law.description.lower() or keyword.lower() in law.title.lower()]

    @staticmethod
    def filter_by_category(laws, category):
        return [law for law in laws if law.category.lower() == category.lower()]


class LegalSystem:
    def __init__(self):
        self.laws = []

    def add_law(self, law):
        self.laws.append(law)

    def list_laws(self):
        for law in self.laws:
            print(law)
            for innovation in law.innovations:
                print("  →", innovation)
            print()

    def search_laws(self, keyword):
        results = LegalToolkit.search_by_keyword(self.laws, keyword)
        for r in results:
            print(r)

    def filter_laws(self, category):
        results = LegalToolkit.filter_by_category(self.laws, category)
        for r in results:
            print(r)

# 🔧 Voorbeelddata
law1 = Law("AVG", "Bescherming persoonsgegevens in de EU", date(2018, 5, 25), "Privacy")
law1.add_innovation(Innovation("AI Privacy Monitor", "Machine Learning", "Analyseert privacy-incidenten in real time"))

law2 = Law("Energie Wet 2023", "Regulatie van duurzame energie", date(2023, 1, 1), "Duurzaamheid")
law2.add_innovation(Innovation("SmartGrid NL", "IoT", "Slim energienetwerk met realtime verdeling"))

# ⚙️ Systeem gebruiken
system = LegalSystem()
system.add_law(law1)
system.add_law(law2)

print("📚 Alle Wetten en Innovaties:")
system.list_laws()

print("\n🔎 Zoek op 'energie':")
system.search_laws("energie")

print("\n📂 Filter op categorie 'Privacy':")
system.filter_laws("Privacy")
