import matplotlib.pyplot as plt
from collections import defaultdict

# Voorbeeldkosten per artikel (dit zou uit je systeem moeten komen)
kosten_per_artikel = {
    1: 50,  # Artikel 1 kost 50 eenheden
    2: 120,  # Artikel 2 kost 120 eenheden
    3: 80,  # Artikel 3 kost 80 eenheden
    # Voeg meer artikelen toe met hun kosten
}

def kosten_per_artikel_dashboard():
    # Visualiseer de kosten per artikel
    artikelen = list(kosten_per_artikel.keys())
    kosten = list(kosten_per_artikel.values())

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(artikelen, kosten, color='salmon')
    ax.set_xlabel('Artikel ID')
    ax.set_ylabel('Kosten in eenheden')
    ax.set_title('Kosten per Artikel')
    plt.tight_layout()
    plt.show()

def kosten_per_maand():
    verkoop = verkoopgeschiedenis.laad_verkoopgeschiedenis()
    maand_kosten = defaultdict(float)

    for v in verkoop:
        maand = v.verkoop_datum.strftime('%Y-%m')  # Maand in formaat 'YYYY-MM'
        kosten = kosten_per_artikel.get(v.artikel_id, 0) * v.aantal
        maand_kosten[maand] += kosten

    # Plot de kosten per maand
    maanden = list(maand_kosten.keys())
    kosten = list(maand_kosten.values())

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(maanden, kosten, marker='o', color='r', label="Kosten per Maand")
    ax.set_xlabel('Maand')
    ax.set_ylabel('Kosten in eenheden')
    ax.set_title('Kosten per Maand')
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
