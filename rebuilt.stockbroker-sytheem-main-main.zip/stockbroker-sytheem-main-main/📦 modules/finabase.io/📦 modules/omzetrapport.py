import matplotlib.pyplot as plt
from datetime import datetime
from collections import defaultdict
from modules import verkoopgeschiedenis

# Voorbeeldprijs per artikel (dit zou uit je voorraadbeheersysteem moeten komen)
prijs_per_artikel = {
    1: 100,  # Artikel 1 kost 100 eenheden
    2: 200,  # Artikel 2 kost 200 eenheden
    3: 150,  # Artikel 3 kost 150 eenheden
    # Voeg meer artikelen toe met hun prijs
}

def omzet_per_maand():
    verkoop = verkoopgeschiedenis.laad_verkoopgeschiedenis()
    maand_omzet = defaultdict(float)

    for v in verkoop:
        maand = v.verkoop_datum.strftime('%Y-%m')  # Maand in formaat 'YYYY-MM'
        omzet = prijs_per_artikel.get(v.artikel_id, 0) * v.aantal
        maand_omzet[maand] += omzet

    # Plot de omzet per maand
    maanden = list(maand_omzet.keys())
    omzetten = list(maand_omzet.values())

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(maanden, omzetten, marker='o', color='b', label="Omzet per Maand")
    ax.set_xlabel('Maand')
    ax.set_ylabel('Omzet in eenheden')
    ax.set_title('Omzet per Maand')
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def omzet_per_artikel():
    verkoop = verkoopgeschiedenis.laad_verkoopgeschiedenis()
    artikel_omzet = defaultdict(float)

    for v in verkoop:
        omzet = prijs_per_artikel.get(v.artikel_id, 0) * v.aantal
        artikel_omzet[v.artikel_id] += omzet

    # Plot de omzet per artikel
    artikelen = list(artikel_omzet.keys())
    omzetten = list(artikel_omzet.values())

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(artikelen, omzetten, color='lightgreen')
    ax.set_xlabel('Artikel ID')
    ax.set_ylabel('Omzet in eenheden')
    ax.set_title('Omzet per Artikel')
    plt.tight_layout()
    plt.show()
