import matplotlib.pyplot as plt
import seaborn as sns
from modules import voorraadbeheer, automatische_bestelling, verkoopgeschiedenis

# Functie om de voorraadstatus te visualiseren
def voorraad_dashboard():
    voorraad = voorraadbeheer.laad_voorraad()
    artikelen = [item.artikel_id for item in voorraad]
    aantallen = [item.aantal for item in voorraad]
    minimum_aantallen = [item.minimum_aantal for item in voorraad]

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(artikelen, aantallen, label="Actuele Voorraad", color='lightblue')
    ax.bar(artikelen, minimum_aantallen, label="Minimum Voorraad", color='salmon', alpha=0.5)
    ax.set_xlabel('Artikel ID')
    ax.set_ylabel('Aantal op Voorraad')
    ax.set_title('Voorraad Status per Artikel')
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Functie om verkooptrends te visualiseren
def verkoop_trends_dashboard():
    verkoop = verkoopgeschiedenis.laad_verkoopgeschiedenis()
    artikelen = [v.artikel_id for v in verkoop]
    aantallen = [v.aantal for v in verkoop]
    datums = [v.verkoop_datum for v in verkoop]

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(datums, aantallen, marker='o', linestyle='-', color='g', label="Aantal Verkocht")
    ax.set_xlabel('Datum')
    ax.set_ylabel('Aantal Verkocht')
    ax.set_title('Verkooptrends per Artikel')
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Functie om de automatische bestellingen te visualiseren
def automatische_bestellingen_dashboard():
    bestellingen = automatische_bestelling.laad_automatische_bestellingen()
    artikel_ids = [b.artikel_id for b in bestellingen]
    aantallen = [b.aantal_bestellen for b in bestellingen]
    datums = [b.bestelling_datum for b in bestellingen]

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(artikel_ids, aantallen, color='orange')
    ax.set_xlabel('Artikel ID')
    ax.set_ylabel('Aantal te Bestellen')
    ax.set_title('Automatische Bestellingen per Artikel')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Samenvatting Dashboard
def toon_dashboard():
    print("📊 Dashboard:\n")
    print("1. Voorraadstatus visualiseren")
    print("2. Verkooptrends visualiseren")
    print("3. Automatische bestellingen visualiseren")
    keuze = input("Kies een optie (1-3): ")

    if keuze == "1":
        voorraad_dashboard()
    elif keuze == "2":
        verkoop_trends_dashboard()
    elif keuze == "3":
        automatische_bestellingen_dashboard()
    else:
        print("Ongeldige keuze. Probeer opnieuw.")
