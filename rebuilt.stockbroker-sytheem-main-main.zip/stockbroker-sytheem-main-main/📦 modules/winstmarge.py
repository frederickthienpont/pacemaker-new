elif keuze == "57":
    omzetrapport.omzet_per_maand(1)
elif keuze == "58":
    omzetrapport.omzet_per_artikel(1)
elif keuze == "59":
    kostenanalyse.kosten_per_maand(1)
elif keuze == "60":
    kostenanalyse.kosten_per_artikel_dashboard(1)
elif keuze == "61":
    winstmarge.bereken_winstmarges(1)
print("\y[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[21] Project toevoegen\n[22] Projecten tonen\n[23] Taak toevoegen\n[24] Taak voltooien\n[25] Product toevoegen\n[26] Producten tonen\n[27] Bestelling maken\n[28] Bestelling verzenden\n[29] Artikel toevoegen\n[30] Artikelen tonen\n[31] Artikel zoeken\n[32] Voorraad bijwerken\n[33] Bestelling plaatsen\n[34] Bestellingen tonen\n[35] Bestelling verzenden\n[36] Bestelling ontvangen\n[37] Leverancier toevoegen\n[38] Leveranciers tonen\n[39] Leverancier zoeken\n[40] Beoordeling toevoegen\n[41] Beoordelingen tonen\n[42] Beoordelingen zoeken\n[43] Factuur genereren\n[44] Facturen tonen\n[45] Betaling verwerken\n[46] Omzetrapport genereren\n[47] Kostenrapport genereren\n[48] Winstrapport genereren\n[49] Voorraad bijwerken\n[50] Voorraad tonen\n[51] Logistiek rapport genereren\n[52] Voorraadwaarschuwingen controleren\n[53] Automatische bestellingen plaatsen\n[54] Automatische bestellingen tonen\n[55] Verkoopgeschiedenis tonen\n[56] Dashboard tonen\n[57]

from modules import omzetrapport, kostenanalyse

def bereken_winstmarges():
    omzet_per_artikel_data = omzetrapport.omzet_per_artikel()
    kosten_per_artikel_data = kostenanalyse.kosten_per_artikel()

    winst_marges = {}
    for artikel_id in omzet_per_artikel_data:
        omzet = omzet_per_artikel_data.get(artikel_id, 0)
        kosten = kosten_per_artikel_data.get(artikel_id, 0)
        
        if omzet > 0:  # Vermijd deling door nul
            winst_marges[artikel_id] = ((omzet - kosten) / omzet) * 100
        else:
            winst_marges[artikel_id] = 0
    
    # Visualiseer de winstmarges
    artikelen = list(winst_marges.keys())
    marges = list(winst_marges.values())

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(artikelen, marges, color='lightblue')
    ax.set_xlabel('Artikel ID')
    ax.set_ylabel('Winstmarge (%)')
    ax.set_title('Winstmarge per Artikel')
    plt.tight_layout()
    plt.show()

    return winst_marges
