from modules import finance

# Binnen de loop:
elif keuze == "15":
    finance.voeg_factuur_toe(1)
elif keuze == "16":
    finance.toon_facturen(1)
elif keuze == "17":
    finance.betaal_factuur(1)
print("\n[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[0] Afsluiten")
