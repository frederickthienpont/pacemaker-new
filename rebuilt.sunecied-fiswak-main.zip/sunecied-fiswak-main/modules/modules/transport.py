from pydantic import BaseModel, Field, validator
from datetime import date, datetime
from typing import List
import json
import os

DATA_FILE = "data/rijbewijzen.json"

class Rijbewijs(BaseModel):
    naam: str
    type: str = Field(..., regex="^[A-CE]{1,2}$")  # A, B, BE, C, CE, enz.
    uitgegeven_op: date
    vervalt_op: date

    @validator("vervalt_op")
    def check_expiry(cls, v, values):
        if "uitgegeven_op" in values and v <= values["uitgegeven_op"]:
            raise ValueError("Vervaldatum moet later zijn dan de uitgiftedatum.")
        return v

def laad_rijbewijzen() -> List[Rijbewijs]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Rijbewijs(**r) for r in data]

def opslaan_rijbewijzen(rijbewijzen: List[Rijbewijs]):
    with open(DATA_FILE, "w") as f:
        json.dump([r.dict() for r in rijbewijzen], f, indent=2, default=str)

def voeg_rijbewijs_toe():
    print("🚘 Nieuw rijbewijs invoeren:")
    try:
        naam = input("Naam: ")
        type_rijbewijs = input("Type (bijv. B, C, CE): ").upper()
        uitgegeven_op = input("Uitgegeven op (YYYY-MM-DD): ")
        vervalt_op = input("Vervalt op (YYYY-MM-DD): ")
        nieuw = Rijbewijs(
            naam=naam,
            type=type_rijbewijs,
            uitgegeven_op=datetime.strptime(uitgegeven_op, "%Y-%m-%d").date(),
            vervalt_op=datetime.strptime(vervalt_op, "%Y-%m-%d").date()
        )
    except Exception as e:
        print("❌ Fout bij invoer:", e)
        return

    rijbewijzen = laad_rijbewijzen()
    rijbewijzen.append(nieuw)
    opslaan_rijbewijzen(rijbewijzen)
    print("✅ Rijbewijs opgeslagen.")

def toon_rijbewijzen():
    rijbewijzen = laad_rijbewijzen()
    if not rijbewijzen:
        print("ℹ️ Geen rijbewijzen gevonden.")
        return
    print("📋 Rijbewijzen in systeem:")
    for r in rijbewijzen:
        print(f" - {r.naam}, type {r.type} (uitgegeven op {r.uitgegeven_op}, vervalt op {r.vervalt_op})")

def info():
    return "Transportmodule actief – rijbewijzenbeheer klaar"
