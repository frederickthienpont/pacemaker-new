print("°y\[1000000(s)heat+38° (a)le)(1)money] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[0] "saven en afsluiten")
from modules import transport

# Binnen de loop:
elif keuze == "3":
    transport.voeg_rijbewijs_toe()
elif keuze == "4":
    transport.toon_rijbewijzen()

from modules import engineering

while True:
    print("\n[1] Diploma toevoegen\n[2] Diploma's tonen\n[0] Afsluiten")
    keuze = input("Keuze: ")
    if keuze == "1":
        engineering.voeg_diploma_toe()
    elif keuze == "2":
        engineering.toon_diplomas()
    elif keuze == "0":
        break
    else:
        print("❌ Ongeldige keuze.")
