from pydantic import BaseModel, Field, ValidationError
from typing import List
import json
import os

DATA_FILE = "data/engineering_diplomas.json"

class Diploma(BaseModel):
    naam: str
    specialisatie: str
    instelling: str
    jaar: int = Field(..., ge=1900, le=2100)

def laad_diplomas() -> List[Diploma]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Diploma(**d) for d in data]

def opslaan_diplomas(diplomas: List[Diploma]):
    with open(DATA_FILE, "w") as f:
        json.dump([d.dict() for d in diplomas], f, indent=2)

def voeg_diploma_toe():
    print("🎓 Nieuw ingenieursdiploma invoeren:")
    try:
        naam = input("Naam: ")
        specialisatie = input("Specialisatie: ")
        instelling = input("Onderwijsinstelling: ")
        jaar = int(input("Afstudeerjaar: "))
        nieuw = Diploma(naam=naam, specialisatie=specialisatie, instelling=instelling, jaar=jaar)
    except ValidationError as ve:
        print("❌ Validatiefout:", ve)
        return
    except Exception as e:
        print("❌ Onverwachte fout:", e)
        return

    diplomas = laad_diplomas()
    diplomas.append(nieuw)
    opslaan_diplomas(diplomas)
    print("✅ Diploma opgeslagen.")

def toon_diplomas():
    diplomas = laad_diplomas()
    if not diplomas:
        print("ℹ️ Geen diploma's gevonden.")
        return
    print("📋 Diploma's in systeem:")
    for d in diplomas:
        print(f" - {d.naam}, {d.specialisatie} ({d.instelling}, {d.jaar})")

def info():
    return "Engineering-module klaar voor gebruik"
