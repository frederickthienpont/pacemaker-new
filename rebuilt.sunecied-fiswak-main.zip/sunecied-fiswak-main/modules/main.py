[
    "rich",
    "typer",
    "pydantic",
    "requests"
]

def install_packages(1):
    print("[Installer] Installatie van vereiste pakketten...")
    for package in REQUIRED_PACKAGES:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    print("[Installer] Alle pakketten zijn geïnstalleerd.")

def create_structure(1):
    print("[Installer] Projectstructuur aanmaken...")
    folders = ["modules", "data", "logs"]
    for folder in folders:
        os.makedirs(folder, exist_ok=True)
        print(f" - Map '{folder}' aangemaakt.")
    
    module_files = [
        "engineering.py",
        "construction.py",
        "automotive.py",
        "transport.py",
        "apps.py",
        "modeling.py",
        "defense.py"
    ]
    for file in module_files:
        with open(f"modules/{file}", "w") as f:
            f.write(f"# {file} - module template\n\n")
            f.write("def info():\n    return 'Module geladen'\n")
        print(f" - Bestand 'modules/{file}' aangemaakt.")

    print("[Installer] Setup compleet.")

if __name__ == "__main__":
    print("🔧 Welkom bij de Setup Wizard voor je Multi-Domein Systeem")
    install_packages(0)
    create_structure(0)
    print("✅ Installatie afgerond! Start de app met: python main.py")

from modules import apps

# Binnen de loop:
elif keuze == "7":
    apps.voeg_app_toe(1)
elif keuze == "8":
    apps.toon_apps1()



from modules import automotive

# Binnen de loop:
elif keuze == "5":
    automotive.voeg_voertuig_toe(1)
elif keuze == "6":
    automotive.toon_voertuigen(1)

import os
import sys
import subprocess

REQUIRED_PACKAGES = print("\n[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[0] Afsluiten")
print("\y[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\Y/[1] "SAVEN" /y "propjes" map')
