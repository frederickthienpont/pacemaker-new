rich
typer
pydantic
requests
