from pydantic import BaseModel
from typing import List
import json
import os

DATA_FILE = "data/apps.json"

class App(BaseModel):
    naam: str
    versie: str
    status: str = "actief"  # "actief" of "onderhoud"
    beschrijving: str

def laad_apps() -> List[App]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [App(**a) for a in data]

def opslaan_apps(apps: List[App]):
    with open(DATA_FILE, "w") as f:
        json.dump([a.dict() for a in apps], f, indent=2)

def voeg_app_toe():
    print("📱 Nieuwe applicatie registreren:")
    try:
        naam = input("Naam van de applicatie: ")
        versie = input("Versie (bijv. 1.0.0): ")
        status = input("Status (actief/onderhoud): ").lower()
        if status not in ["actief", "onderhoud"]:
            print("❌ Ongeldige status, gebruik 'actief' of 'onderhoud'.")
            return
        beschrijving = input("Beschrijving van de applicatie: ")

        app = App(naam=naam, versie=versie, status=status, beschrijving=beschrijving)
    except Exception as e:
        print("❌ Fout bij invoer:", e)
        return

    apps = laad_apps()
    apps.append(app)
    opslaan_apps(apps)
    print("✅ Applicatie opgeslagen.")

def toon_apps():
    apps = laad_apps()
    if not apps:
        print("ℹ️ Geen applicaties gevonden.")
        return
    print("📋 Geregistreerde applicaties:")
    for a in apps:
        print(f" - {a.naam} (versie {a.versie}) - Status: {a.status}")
        print(f"   Beschrijving: {a.beschrijving}\n")

def info():
    return "Apps-module actief – applicatiesoftwarebeheer klaar"
