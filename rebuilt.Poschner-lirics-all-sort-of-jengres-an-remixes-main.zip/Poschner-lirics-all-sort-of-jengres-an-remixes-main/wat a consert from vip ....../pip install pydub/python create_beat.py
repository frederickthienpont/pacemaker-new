from pydub import AudioSegment
from pydub.generators import Sine

# Create a deep bass drum sound (kick) with a sine wave
def create_kick(frequency=50, duration_ms=250):
    return Sine(frequency).to_audio_segment(duration=duration_ms).low_pass_filter(150)

# Create a snare sound (sharp hit) with a sine wave
def create_snare(frequency=200, duration_ms=150):
    return Sine(frequency).to_audio_segment(duration=duration_ms).high_pass_filter(1000)

# Create a hi-hat sound (sharp metallic sound)
def create_hihat(frequency=5000, duration_ms=100):
    return Sine(frequency).to_audio_segment(duration=duration_ms).high_pass_filter(3000)

# Create the 1-2-3-4 beat pattern
def create_beat():
    # Kick: 1st beat (deep bass)
    kick = create_kick()

    # Snare: 2nd and 4th beats (sharp snare hit)
    snare = create_snare()

    # Hi-hat: 8th notes (constant, sharp sound)
    hihat = create_hihat()

    # Build the beat pattern (1-2-3-4)
    # Kick on 1, Snare on 2 and 4, Hi-hat on all beats
    beat = kick + hihat + snare + hihat  # 1-2-3-4

    # Repeat the pattern 4 times to make it loop
    full_beat = beat * 4

    return full_beat

# Create the full beat loop
beat = create_beat()

# Export the beat to a WAV file
beat.export("extreme_beat.wav", format="wav")

print("Beat created and saved as extreme_beat.wav")
