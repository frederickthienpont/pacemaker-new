import json
from datetime import datetime
import os

class Rijbewijs:
    def __init__(self, naam, adres, stad, postcode, land, geboortedatum, rijbewijs_categorie, paspoort_nummer=None):
        self.naam = naam
        self.adres = adres
        self.stad = stad
        self.postcode = postcode
        self.land = land
        self.geboortedatum = geboortedatum
        self.rijbewijs_categorie = rijbewijs_categorie
        self.paspoort_nummer = paspoort_nummer
        self.gegevens = {
            "naam": naam,
            "adres": adres,
            "stad": stad,
            "postcode": postcode,
            "land": land,
            "geboortedatum": geboortedatum,
            "rijbewijs_categorie": rijbewijs_categorie,
            "paspoort_nummer": paspoort_nummer
        }
        self.betalingen = []
        self.examen_resultaten = []
        self.strafblad = False
        self.stemgedrag = ""
        self.rechthebbende = False
        self.licentie_in_handen = False
        self.eigen_wagen = False
        self.boetes = []
        self.afbetalingen = []
        self.keuringsbewijs = False
        self.child_info = []

    def betaling(self, bedrag, datum):
        betaling = {
            "bedrag": bedrag,
            "datum": datum,
            "betaald": True
        }
        self.betalingen.append(betaling)

    def voeg_examen_resultaat_toe(self, examen_type, resultaat, datum):
        examen_resultaat = {
            "examen_type": examen_type,
            "resultaat": resultaat,
            "datum": datum
        }
        self.examen_resultaten.append(examen_resultaat)

    def wijzig_strafblad(self, strafblad_status):
        self.strafblad = strafblad_status

    def wijzig_stemgedrag(self, partij):
        self.stemgedrag = partij

    def voeg_boete_toe(self, boete):
        self.boetes.append(boete)

    def voeg_afbetaling_toe(self, bedrag, datum):
        afbetaling = {
            "bedrag": bedrag,
            "datum": datum
        }
        self.afbetalingen.append(afbetaling)

    def wijzig_keuring(self, status):
        self.keuringsbewijs = status

    def voeg_kind_toe(self, naam, geboortedatum):
        kind = {
            "naam": naam,
            "geboortedatum": geboortedatum
        }
        self.child_info.append(kind)

    def geef_rijbewijs(self):
        if all(res["resultaat"] == "geslaagd" for res in self.examen_resultaten) and self.keuringsbewijs:
            self.licentie_in_handen = True
            return "Rijbewijs verleend."
        else:
            return "Rijbewijs niet verleend, examen niet behaald of keuringsbewijs ontbreekt."

    def print_gegevens(self):
        print(json.dumps(self.gegevens, indent=4))

    def exporteer_gegevens(self, bestand):
        with open(bestand, 'w') as f:
            json.dump(self.gegevens, f, indent=4)

    def print_afbetalingen(self):
        for afbetaling in self.afbetalingen:
            print(f"Afbetaling van {afbetaling['bedrag']} op {afbetaling['datum']}")

# Gebruik
def main():
    print("Welkom bij het Rijbewijs Administratie Systeem!")
    naam = input("Voer de naam in: ")
    adres = input("Voer het adres in: ")
    stad = input("Voer de stad in: ")
    postcode = input("Voer de postcode in: ")
    land = input("Voer het land in: ")
    geboortedatum = input("Voer de geboortedatum in (YYYY-MM-DD): ")
    rijbewijs_categorie = input("Voer de rijbewijs categorie in (bijv. A, B, C): ")
    paspoort_nummer = input("Voer het paspoortnummer in (indien beschikbaar): ")

    student = Rijbewijs(naam, adres, stad, postcode, land, geboortedatum, rijbewijs_categorie, paspoort_nummer)

    while True:
        print("\nKies een optie:")
        print("1. Voeg betaling toe")
        print("2. Voeg examenresultaat toe")
        print("3. Voeg boete toe")
        print("4. Voeg afbetaling toe")
        print("5. Voeg kind toe")
        print("6. Toon rijbewijs")
        print("7. Exporteren naar bestand")
        print("8. Afsluiten")

        keuze = input("Kies een optie (1-8): ")

        if keuze == "1":
            bedrag = float(input("Voer het bedrag van de betaling in: "))
            datum = input("Voer de datum van betaling in (YYYY-MM-DD): ")
            student.betaling(bedrag, datum)
        elif keuze == "2":
            examen_type = input("Voer het examen type in (Theorie/Praktijk): ")
            resultaat = input("Voer het resultaat in (geslaagd/gezakt): ")
            datum = input("Voer de datum in (YYYY-MM-DD): ")
            student.voeg_examen_resultaat_toe(examen_type, resultaat, datum)
        elif keuze == "3":
            boete = input("Voer de boeteomschrijving in: ")
            student.voeg_boete_toe(boete)
        elif keuze == "4":
            bedrag = float(input("Voer het bedrag van de afbetaling in: "))
            datum = input("Voer de datum van afbetaling in (YYYY-MM-DD): ")
            student.voeg_afbetaling_toe(bedrag, datum)
        elif keuze == "5":
            kind_naam = input("Voer de naam van het kind in: ")
            kind_geboortedatum = input("Voer de geboortedatum van het kind in (YYYY-MM-DD): ")
            student.voeg_kind_toe(kind_naam, kind_geboortedatum)
        elif keuze == "6":
            print(student.geef_rijbewijs())
        elif keuze == "7":
            bestand = input("Voer de naam van het bestand in (bijv. rijbewijs_data.json): ")
            student.exporteer_gegevens(bestand)
        elif keuze == "8":
            print("Afsluiten... Bedankt voor het gebruik van het systeem!")
            break
        else:
            print("Ongeldige keuze. Probeer het opnieuw.")

if __name__ == "__main__":
    main()
