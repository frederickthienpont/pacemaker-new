# We voegen een extra bestand toe aan het bestaande zip-project voor een "Upgrade Console Menu"

upgrade_menu_code = """
import pygame

pygame.init()
screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption("Deadwish Upgrade Console")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (180, 180, 180)
BLUE = (50, 150, 255)
GREEN = (0, 200, 100)
RED = (200, 50, 50)

font = pygame.font.SysFont(None, 36)
small_font = pygame.font.SysFont(None, 28)

options = [
    {"label": "🔧 Upgrade MO-Motor (Level 2)", "activated": False},
    {"label": "💻 Installeer Ferrari Console", "activated": False},
    {"label": "⚡ Turbo Boost Activeren", "activated": False},
    {"label": "🎮 Pilootsysteem: Actief", "activated": False}
]

def draw_menu():
    screen.fill((25, 25, 25))
    title = font.render("🛠️ Deadwish Upgrade Console", True, WHITE)
    screen.blit(title, (30, 30))

    for i, option in enumerate(options):
        y = 100 + i * 60
        color = GREEN if option["activated"] else GRAY
        pygame.draw.rect(screen, color, (50, y, 500, 40), border_radius=8)
        label = small_font.render(option["label"], True, BLACK if option["activated"] else WHITE)
        screen.blit(label, (60, y + 8))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            for i, option in enumerate(options):
                rect = pygame.Rect(50, 100 + i * 60, 500, 40)
                if rect.collidepoint(x, y):
                    option["activated"] = not option["activated"]

    draw_menu()
    pygame.display.update()
"""

# Voeg het bestand toe aan het zip-archief
updated_zip_path = "/mnt/data/deadwish_upgrade_console.zip"
with zipfile.ZipFile(updated_zip_path, 'w') as zf:
    zf.writestr("main.py", project_files["main.py"])
    zf.writestr("arrival.wav", b"")  # Leeg geluidsbestand als placeholder
    zf.writestr("upgrade_console.py", upgrade_menu_code)

updated_zip_path
