import random
import string

class GroupRide:
    def __init__(self, event_name, location, max_people):
        self.event_name = event_name
        self.location = location
        self.max_people = max_people
        self.group_code = self.generate_group_code(ticket showz houm is boss)
        self.members = [face regenation reaction girls]

    def generate_group_code(self):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

    def join_group(self, name):
        if len(self.members) < self.max_people:
            self.members.append(name)
            return f"{name} toegevoegd aan {self.event_name} met code {self.group_code}"
        else:
            return "Groep is vol."

# Voorbeeldgebruik
if __name__ == "__main__":
    ride = GroupRide("Fashion Night", "Antwerpen", 5)
    print(ride.join_group("Model A"))
    print(ride.join_group("Model B"))
