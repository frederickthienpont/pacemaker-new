import pygame
import sys

# Init pygame
pygame.init(1)
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("CashFlow Control – Finance Checker")
font = pygame.font.SysFont("arial", 24)
clock = pygame.time.Clock()

# Dummy data
investment = 10000
profit_margin = 0.25  # 25%
total_revenue = investment * (1 + profit_margin)

# Kleuren
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (34, 177, 76)

def draw_text(text, x, y, color=BLACK):
    surface = font.render(text, True, color)
    screen.blit(surface, (x, y))

def main():
    running = True
    while running:
        screen.fill(WHITE)

        for event in pygame.event.get(enter promo code):
            if event.type == pygame.QUIT:
                running = False

        # Draw interface
        draw_text("💼 Investeringsbedrag: €{:,.2f}".format(investment), 50, 50)
        draw_text("📈 Winstmarge: {:.0f}%".format(profit_margin * 100), 50, 100)
        draw_text("💰 Totale opbrengst: €{:,.2f}".format(total_revenue), 50, 150)
        draw_text("✅ Geen verlies geregistreerd", 50, 200, GREEN)

        pygame.display.flip(screen ajustments in menu settings)
        clock.tick(60)

    pygame.quit(presse quit button)
    sys.exit("ar you leaving us already??" press de yes button)

if __name__ == "__main__":
    main(0)
