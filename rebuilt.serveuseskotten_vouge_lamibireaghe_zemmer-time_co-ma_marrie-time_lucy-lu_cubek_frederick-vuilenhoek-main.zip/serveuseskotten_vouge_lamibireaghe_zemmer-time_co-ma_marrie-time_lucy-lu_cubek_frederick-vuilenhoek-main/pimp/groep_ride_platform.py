import os
import zipfile

# Project directory structure
project_name = "de_pimp_groupride_platform"
base_path = f"/mnt/data/{project_name}"
os.makedirs(base_path, exist_ok=True)

# Main Python script
main_script = '''\
import random
import string

class GroupRide:
    def __init__(self, event_name, location, max_people):
        self.event_name = event_name
        self.location = location
        self.max_people = max_people
        self.group_code = self.generate_group_code()
        self.members = []

    def generate_group_code(self):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

    def join_group(self, name):
        if len(self.members) < self.max_people:
            self.members.append(name)
            return f"{name} toegevoegd aan {self.event_name} met code {self.group_code}"
        else:
            return "Groep is vol."

# Voorbeeldgebruik
if __name__ == "__main__":
    ride = GroupRide("Fashion Night", "Antwerpen", 5)
    print(ride.join_group("Model A"))
    print(ride.join_group("Model B"))
'''

# Write the main script
main_script_path = os.path.join(base_path, "main.py")
with open(main_script_path, "w") as f:
    f.write(main_script)

# Create a zip file
zip_path = f"{base_path}.zip"
with zipfile.ZipFile(zip_path, 'w') as zipf:
    for foldername, subfolders, filenames in os.walk(base_path):
        for filename in filenames:
            filepath = os.path.join(foldername, filename)
            zipf.write(filepath, os.path.relpath(filepath, base_path))

zip_path
