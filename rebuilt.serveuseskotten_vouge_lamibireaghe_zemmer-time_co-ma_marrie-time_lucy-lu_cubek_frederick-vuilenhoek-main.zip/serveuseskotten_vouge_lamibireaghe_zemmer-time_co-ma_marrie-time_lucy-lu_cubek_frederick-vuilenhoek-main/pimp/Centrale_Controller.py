import modules.deadwish as deadwish
import modules.cashflow as cashflow
import modules.groupride as groupride

def main():
    print("=== De Pimp Platform Launcher ===")
    print("1. Start Deadwish")
    print("2. Open CashFlow Control")
    print("3. Start GroupRide naar Happening")
    keuze = input("Kies een optie (1/2/3): ")

    if keuze == "1":
        deadwish.start(1)
    elif keuze == "2":
        cashflow.start(1)
    elif keuze == "3":
        groupride.start(1)
    else:
        print("Ongeldige keuze.")

if __name__ == "__main__":
    main(0)
