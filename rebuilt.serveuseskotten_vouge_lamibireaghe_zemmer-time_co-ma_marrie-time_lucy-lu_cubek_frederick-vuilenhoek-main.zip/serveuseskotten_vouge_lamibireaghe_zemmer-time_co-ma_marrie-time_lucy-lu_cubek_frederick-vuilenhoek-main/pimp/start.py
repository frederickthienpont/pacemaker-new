import os
import zipfile

# Project directory structure
project_name = "de_pimp_platform"
base_path = f"/mnt/data/{project_name}"
modules_path = os.path.join(base_path, "modules")
os.makedirs(modules_path, exist_ok=True)

# main.py
main_py = '''\
import modules.deadwish as deadwish
import modules.cashflow as cashflow
import modules.groupride as groupride

def main():
    print("=== De Pimp Platform Launcher ===")
    print("1. Start Deadwish")
    print("2. Open CashFlow Control")
    print("3. Start GroupRide naar Happening")
    keuze = input("Kies een optie (1/2/3): ")

    if keuze == "1":
        deadwish.start()
    elif keuze == "2":
        cashflow.start()
    elif keuze == "3":
        groupride.start()
    else:
        print("Ongeldige keuze.")

if __name__ == "__main__":
    main()
'''

# modules/__init__.py
init_py = ''

# modules/deadwish.py
deadwish_py = '''\
def start():
    print("[Deadwish] Deadwish console gestart...")
    # Voeg hier je Deadwish-code in
'''

# modules/cashflow.py
cashflow_py = '''\
def start():
    print("[CashFlow] Controle gestart op opbrengsten en investeringen...")
    # Voeg hier je CashFlow Control-code in
'''

# modules/groupride.py
groupride_py = '''\
def start():
    print("[GroupRide] Systeem gestart voor groepsvervoer naar evenement!")
    # Voeg hier je GroupRide-code in
'''

# Write files
files = {
    os.path.join(base_path, "main.py"): main_py,
    os.path.join(modules_path, "__init__.py"): init_py,
    os.path.join(modules_path, "deadwish.py"): deadwish_py,
    os.path.join(modules_path, "cashflow.py"): cashflow_py,
    os.path.join(modules_path, "groupride.py"): groupride_py,
}

for path, content in files.items():
    with open(path, "w") as f:
        f.write(content)

# Create zip file
zip_path = f"{base_path}.zip"
with zipfile.ZipFile(zip_path, 'w') as zipf:
    for foldername, subfolders, filenames in os.walk(base_path):
        for filename in filenames:
            filepath = os.path.join(foldername, filename)
            zipf.write(filepath, os.path.relpath(filepath, base_path))

zip_path
