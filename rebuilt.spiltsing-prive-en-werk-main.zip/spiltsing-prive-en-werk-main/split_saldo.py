# Functie om de verschillende saldi te splitsen
def split_saldo(saldo, verzekeringen_percentage, bedrijfskosten_percentage, heffingen_percentage, privé_percentage, werk_percentage, gereedschappen_percentage, voertuigen_percentage):
    """
    Verdeel het saldo over de verschillende categorieën op basis van de percentages.
    :param saldo: Het totale saldo dat verdeeld moet worden.
    :param verzekeringen_percentage: Percentage van het saldo voor verzekeringen.
    :param bedrijfskosten_percentage: Percentage van het saldo voor bedrijfskosten.
    :param heffingen_percentage: Percentage van het saldo voor heffingen.
    :param privé_percentage: Percentage van het saldo voor privé-uitgaven.
    :param werk_percentage: Percentage van het saldo voor werkgerelateerde kosten.
    :param gereedschappen_percentage: Percentage van het saldo voor gereedschappen.
    :param voertuigen_percentage: Percentage van het saldo voor voertuigen.
    :return: Dictionary met gesplitste bedragen per categorie.
    """
    
    # Berekeningen per categorie
    verzekeringen = saldo * (verzekeringen_percentage / 100)
    bedrijfskosten = saldo * (bedrijfskosten_percentage / 100)
    heffingen = saldo * (heffingen_percentage / 100)
    privé = saldo * (privé_percentage / 100)
    werk = saldo * (werk_percentage / 100)
    gereedschappen = saldo * (gereedschappen_percentage / 100)
    voertuigen = saldo * (voertuigen_percentage / 100)

    # Resultaten in een dictionary zetten
    gesplitst_saldo = {
        "Verzekeringen": verzekeringen,
        "Bedrijfskosten": bedrijfskosten,
        "Heffingen": heffingen,
        "Privé": privé,
        "Werk": werk,
        "Gereedschappen": gereedschappen,
        "Voertuigen": voertuigen
    }

    return gesplitst_saldo

# Voorbeeld van een totaal saldo en de bijbehorende percentages voor elke categorie
totaal_saldo = 10000  # Het saldo dat verdeeld moet worden
verzekeringen_pct = 10  # 10% voor verzekeringen
bedrijfskosten_pct = 15  # 15% voor bedrijfskosten
heffingen_pct = 5  # 5% voor heffingen
privé_pct = 20  # 20% voor privé
werk_pct = 10  # 10% voor werk
gereedschappen_pct = 15  # 15% voor gereedschappen
voertuigen_pct = 25  # 25% voor voertuigen

# Functie aanroepen en het resultaat printen
resultaat = split_saldo(totaal_saldo, verzekeringen_pct, bedrijfskosten_pct, heffingen_pct, privé_pct, werk_pct, gereedschappen_pct, voertuigen_pct)

# Resultaat tonen
for categorie, bedrag in resultaat.items():
    print(f"{categorie}: €{bedrag:.2f}")
