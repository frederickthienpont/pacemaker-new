Verzekeringen: €950.00
Bedrijfskosten: €1425.00
Heffingen: €475.00
Privé: €1900.00
Werk: €950.00
Gereedschappen: €1425.00
Voertuigen: €2375.00
Extra Kosten: €200.00
