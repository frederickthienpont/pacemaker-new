# Functie om de verschillende saldi te splitsen met extra functionaliteiten
def split_saldo(saldo, percentages, extra_kosten=None, belastingkorting=None):
    """
    Verdeel het saldo over de verschillende categorieën op basis van de percentages.
    :param saldo: Het totale saldo dat verdeeld moet worden.
    :param percentages: Dictionary van categorieën met bijbehorende percentages.
    :param extra_kosten: Extra kosten die buiten de percentages vallen (optioneel).
    :param belastingkorting: Kortingen die op het saldo van toepassing zijn (optioneel).
    :return: Dictionary met gesplitste bedragen per categorie.
    """
    
    # Validatie van de percentages
    total_percentage = sum(percentages.values())
    if total_percentage != 100:
        raise ValueError(f"De totalen van de percentages moeten 100% zijn, maar ze zijn {total_percentage}%.")

    # Pas belastingkorting toe (indien aanwezig)
    if belastingkorting:
        saldo = saldo * (1 - belastingkorting / 100)
    
    # Berekeningen per categorie
    gesplitst_saldo = {}
    for categorie, percentage in percentages.items():
        bedrag = saldo * (percentage / 100)
        gesplitst_saldo[categorie] = bedrag

    # Voeg extra kosten toe (indien aanwezig)
    if extra_kosten:
        gesplitst_saldo["Extra Kosten"] = extra_kosten

    return gesplitst_saldo

# Voorbeeld van een totaal saldo en de bijbehorende percentages voor elke categorie
totaal_saldo = 10000  # Het saldo dat verdeeld moet worden
percentages = {
    "Verzekeringen": 10,  # 10% voor verzekeringen
    "Bedrijfskosten": 15,  # 15% voor bedrijfskosten
    "Heffingen": 5,  # 5% voor heffingen
    "Privé": 20,  # 20% voor privé
    "Werk": 10,  # 10% voor werk
    "Gereedschappen": 15,  # 15% voor gereedschappen
    "Voertuigen": 25  # 25% voor voertuigen
}

# Extra kosten en belastingkorting
extra_kosten = 200  # Onverwachte kosten van €200
belastingkorting = 5  # Een belastingkorting van 5%

# Functie aanroepen en het resultaat printen
try:
    resultaat = split_saldo(totaal_saldo, percentages, extra_kosten, belastingkorting)

    # Resultaat tonen
    for categorie, bedrag in resultaat.items():
        print(f"{categorie}: €{bedrag:.2f}")
except ValueError as e:
    print(e)
