Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ===== Veroordeelde gegevens =====
$persoon = [PSCustomObject]@{
    Naam           = "TestSubject-001"
    Status         = "Geregistreerd"
    DetentieJaren  = 40
    Jaar           = 0
    Ingevroren     = $false
    Onthoofd       = $false
}

# ===== GUI Setup =====
$form = New-Object System.Windows.Forms.Form
$form.Text = "X-42 CryoControl Panel"
$form.Size = New-Object System.Drawing.Size(500,400)
$form.StartPosition = "CenterScreen"

$labelTitle = New-Object System.Windows.Forms.Label
$labelTitle.Text = "Bevriezingswet X-42/1927 - Uitvoering"
$labelTitle.Size = New-Object System.Drawing.Size(480,30)
$labelTitle.Location = New-Object System.Drawing.Point(10,10)
$labelTitle.Font = New-Object System.Drawing.Font("Segoe UI",12,[System.Drawing.FontStyle]::Bold)
$form.Controls.Add($labelTitle)

$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Minimum = 0
$progressBar.Maximum = $persoon.DetentieJaren
$progressBar.Size = New-Object System.Drawing.Size(460,25)
$progressBar.Location = New-Object System.Drawing.Point(10,50)
$form.Controls.Add($progressBar)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Status: $($persoon.Status)"
$statusLabel.Size = New-Object System.Drawing.Size(460,25)
$statusLabel.Location = New-Object System.Drawing.Point(10,90)
$form.Controls.Add($statusLabel)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ScrollBars = "Vertical"
$logBox.Size = New-Object System.Drawing.Size(460,170)
$logBox.Location = New-Object System.Drawing.Point(10,120)
$logBox.ReadOnly = $true
$form.Controls.Add($logBox)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = "Start Uitvoering"
$startButton.Size = New-Object System.Drawing.Size(150,30)
$startButton.Location = New-Object System.Drawing.Point(10,300)
$form.Controls.Add($startButton)

# ===== Log Functie =====
Function Schrijf-Log($bericht) {
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logBox.AppendText("[$timestamp] $bericht`r`n")
}

# ===== Uitvoeringslogica =====
$startButton.Add_Click({
    $startButton.Enabled = $false
    Schrijf-Log "Detentie gestart voor $($persoon.Naam)"

    for ($i = 1; $i -le $persoon.DetentieJaren; $i++) {
        Start-Sleep -Milliseconds 200
        $persoon.Jaar = $i
        $progressBar.Value = $i
        $statusLabel.Text = "Status: Detentie - Jaar $i"
        $form.Refresh()
        Schrijf-Log "Detentiejaar $i voltooid."
    }

    # Invriezen
    $persoon.Ingevroren = $true
    $statusLabel.Text = "Status: INGEVROREN"
    Schrijf-Log "$($persoon.Naam) overgebracht naar cryogene bevriezing."
    Start-Sleep -Seconds 2

    # Onthoofding
    $persoon.Onthoofd = $true
    $statusLabel.Text = "Status: ONTHOOFD"
    Schrijf-Log "Schedelseparatie uitgevoerd. Uitvoering voltooid."

    # Eindstatus
    Schrijf-Log "Bevriezingswet X-42/1927 volledig toegepast."
})

# ===== Start GUI =====
[void]$form.ShowDialog()
