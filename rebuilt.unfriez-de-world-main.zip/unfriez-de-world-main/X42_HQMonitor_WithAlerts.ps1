Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Media

# ====== Algemene instellingen ======
$persoon = [PSCustomObject]@{
    Naam           = "TestSubject-001"
    Status         = "Geregistreerd"
    DetentieJaren  = 40
    Jaar           = 0
    Ingevroren     = $false
    Onthoofd       = $false
}

$machines = @(
    @{ Naam = "CryoPod-Alpha"; Temperatuur = -119; Status = "STABIEL"; Beveiliging = "HOOG" },
    @{ Naam = "CryoPod-Beta"; Temperatuur = -122; Status = "WAARSCHUWING"; Beveiliging = "GEMIDDELD" },
    @{ Naam = "ScanDrone-07"; Temperatuur = 36; Status = "ACTIEF"; Beveiliging = "HOOG" },
    @{ Naam = "NeuraLock-21"; Temperatuur = 22; Status = "INACTIEF"; Beveiliging = "LAAG" }
)

# ====== GUI Setup ======
$form = New-Object System.Windows.Forms.Form
$form.Text = "X-42 CryoControl HQ Monitor"
$form.Size = New-Object System.Drawing.Size(800,500)
$form.StartPosition = "CenterScreen"
$form.BackColor = "Black"

$labelHeader = New-Object System.Windows.Forms.Label
$labelHeader.Text = "Cryo Detentie - HQ Beveiligingsmonitor"
$labelHeader.ForeColor = "White"
$labelHeader.Font = New-Object System.Drawing.Font("Segoe UI",14,[System.Drawing.FontStyle]::Bold)
$labelHeader.Size = New-Object System.Drawing.Size(600,30)
$labelHeader.Location = New-Object System.Drawing.Point(10,10)
$form.Controls.Add($labelHeader)

# Machine status grid
$machineList = New-Object System.Windows.Forms.ListView
$machineList.Size = New-Object System.Drawing.Size(500,300)
$machineList.Location = New-Object System.Drawing.Point(10,50)
$machineList.View = "Details"
$machineList.FullRowSelect = $true
$machineList.BackColor = "Black"
$machineList.ForeColor = "Lime"
$machineList.Columns.Add("Machine",150)
$machineList.Columns.Add("Temp (°C)",80)
$machineList.Columns.Add("Status",120)
$machineList.Columns.Add("Beveiliging",120)
$form.Controls.Add($machineList)

# Voeg machines toe
foreach ($m in $machines) {
    $item = New-Object System.Windows.Forms.ListViewItem($m.Naam)
    $item.SubItems.Add($m.Temperatuur.ToString())
    $item.SubItems.Add($m.Status)
    $item.SubItems.Add($m.Beveiliging)
    $machineList.Items.Add($item)
}

# HQ Log
$hqLog = New-Object System.Windows.Forms.TextBox
$hqLog.Multiline = $true
$hqLog.ScrollBars = "Vertical"
$hqLog.Size = New-Object System.Drawing.Size(260,300)
$hqLog.Location = New-Object System.Drawing.Point(520,50)
$hqLog.BackColor = "Black"
$hqLog.ForeColor = "White"
$hqLog.Font = New-Object System.Drawing.Font("Consolas",10)
$hqLog.ReadOnly = $true
$form.Controls.Add($hqLog)

# Visuele Alarm Label
$alarmLabel = New-Object System.Windows.Forms.Label
$alarmLabel.Text = "ALERT"
$alarmLabel.Font = New-Object System.Drawing.Font("Segoe UI",16,[System.Drawing.FontStyle]::Bold)
$alarmLabel.ForeColor = "Red"
$alarmLabel.BackColor = "Black"
$alarmLabel.AutoSize = $true
$alarmLabel.Location = New-Object System.Drawing.Point(650,370)
$alarmLabel.Visible = $false
$form.Controls.Add($alarmLabel)

# Functie om te loggen
function HQ-Log($msg) {
    $time = Get-Date -Format "HH:mm:ss"
    $hqLog.AppendText("[$time] $msg`r`n")
}

# Functie voor alarm
function Start-Alarm {
    $alarmLabel.Visible = $true
    [System.Media.SystemSounds]::Exclamation.Play()
}

# Startknop
$startBtn = New-Object System.Windows.Forms.Button
$startBtn.Text = "Start Monitoring"
$startBtn.Size = New-Object System.Drawing.Size(150,30)
$startBtn.Location = New-Object System.Drawing.Point(10,370)
$form.Controls.Add($startBtn)

# Monitoring logica
$startBtn.Add_Click({
    $startBtn.Enabled = $false
    HQ-Log "Monitoring gestart op hoofdkanaal..."

    for ($jaar = 1; $jaar -le $persoon.DetentieJaren; $jaar++) {
        Start-Sleep -Milliseconds 200
        $persoon.Jaar = $jaar
        HQ-Log "Detentiejaar $jaar - Gecontroleerd."
        if ($jaar % 10 -eq 0) {
            $machineList.Items[1].SubItems[2].Text = "KRITIEK"
            $machineList.Items[1].SubItems[3].Text = "ZEER LAAG"
            $machineList.Items[1].ForeColor = "Red"
            HQ-Log "ALERT: CryoPod-Beta vertoont instabiliteit."
            Start-Alarm
        }
    }

    $persoon.Ingevroren = $true
    HQ-Log "$($persoon.Naam) is nu cryogeen ingevroren."
    Start-Sleep -Seconds 1
    $persoon.Onthoofd = $true
    HQ-Log "$($persoon.Naam) schedelseparatie voltooid."

    HQ-Log "Alle beveiligingsstappen afgerond onder Wet X-42."
})

[void]$form.ShowDialog()
