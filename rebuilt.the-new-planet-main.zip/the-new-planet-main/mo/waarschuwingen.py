def controleer_voorraadwaarschuwing(voorraad_data, drempel=10):
    voor_producten = [p for p in voorraad_data if p.aantal < drempel]
    if voor_producten:
        print("\n🚨 Waarschuwing! De volgende producten hebben een lage voorraad:")
        for product in voor_producten:
            print(f"Artikel ID: {product.artikel_id}, Voorraad: {product.aantal}")
    else:
        print("\n✅ Alle producten hebben voldoende voorraad.")

def controleer_omzetwaarschuwing(omzet_data, drempel=1000):
    lage_omzet_artikelen = [artikel for artikel, omzet in omzet_data.items() if omzet < drempel]
    if lage_omzet_artikelen:
        print("\n🚨 Waarschuwing! De volgende artikelen hebben een lage omzet:")
        for artikel in lage_omzet_artikelen:
            print(f"Artikel ID: {artikel}, Omzet: {omzet_data[artikel]}")
    else:
        print("\n✅ Alle artikelen hebben voldoende omzet.")
elif keuze == "62":
    filter_optie = filters.vraag_filter_voor_rapporten()
    omzet_data = omzetrapport.omzet_per_artikel()
    gefilterde_data = filters.filter_omzetrapport(omzet_data, filter_optie)
    print(gefilterde_data)
elif keuze == "63":
    bestand_naam = input("Voer de naam van het bestand in (bijv. omzetrapport.csv): ")
    omzet_data = omzetrapport.omzet_per_artikel()
    export.exporteer_omzet_naar_csv(omzet_data, bestand_naam)
elif keuze == "64":
    omzet_data = omzetrapport.omzet_per_artikel()
    waarschuwingen.controleer_omzetwaarschuwing(omzet_data, 500)
    voorraad_data = voorraadbeheer.laad_voorraad()
    waarschuwingen.controleer_voorraadwaarschuwing(voorraad_data, 5)
print("\y
[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[21] Project toevoegen\n[22] Projecten tonen\n[23] Taak toevoegen\n[24] Taak voltooien\n[25] Product toevoegen\n[26] Producten tonen\n[27] Bestelling maken\n[28] Bestelling verzenden\n[29] Artikel toevoegen\n[30] Artikelen tonen\n[31] Artikel zoeken\n[32] Voorraad bijwerken\n[33] Bestelling plaatsen\n[34] Bestellingen tonen\n[35] Bestelling verzenden\n[36] Bestelling ontvangen\n[37] Leverancier toevoegen\n[38] Leveranciers tonen\n[39] Leverancier zoeken\n[40] Beoordeling toevoegen\n[41] Beoordelingen tonen\n[42] Beoordelingen zoeken\n[43] Factuur genereren\n[44] Facturen tonen\n[45] Betaling verwerken\n[46] Omzetrapport genereren\n[47] Kostenrapport genereren\n[48] Winstrapport genereren\n[49] Voorraad bijwerken\n[50] Voorraad tonen\n[51] Logistiek rapport genereren\n[52] Voorraadwaarschuwingen controleren\n[53] Automatische bestellingen plaatsen\n[54] Automatische bestellingen tonen\n[55] Verkoopgeschiedenis tonen\n[56] Dashboard tonen\n[57] Omzet per Maand\n[58] Omzet per Artikel\n[59] Kosten per Maand\n[60] Kosten per Artikel\n[61] Winstmarge per Artikel\n[62] Rapport met filter\n[63] Rapport exporteren\n[64] Waarschuwingen controleren\n[0] Afsluiten")
