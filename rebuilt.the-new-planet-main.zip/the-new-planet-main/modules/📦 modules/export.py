import csv

def exporteer_omzet_naar_csv(omzet_data, bestand_naam):
    with open(bestand_naam, mode='w', newline='') as bestand:
        writer = csv.writer(bestand)
        writer.writerow(['Artikel ID', 'Omzet'])
        for artikel_id, omzet in omzet_data.items():
            writer.writerow([artikel_id, omzet])
    print(f"Omzetdata is geëxporteerd naar {bestand_naam}")

def exporteer_omzet_naar_excel(omzet_data, bestand_naam):
    import pandas as pd
    df = pd.DataFrame(list(omzet_data.items()), columns=["Artikel ID", "Omzet"])
    df.to_excel(bestand_naam, index=False)
    print(f"Omzetdata is geëxporteerd naar {bestand_naam}")
