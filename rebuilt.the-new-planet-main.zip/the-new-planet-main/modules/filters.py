def vraag_filter_voor_rapporten():
    print("\nKies een filteroptie:")
    print("[1] Filter op maand")
    print("[2] Filter op artikel")
    print("[3] Filter op productcategorie")
    print("[4] Geen filter (toon alles)")

    keuze = input("Kies een optie (1-4): ")

    if keuze == "1":
        maand = input("Voer de maand in (YYYY-MM): ")
        return {"type": "maand", "waarde": maand}
    elif keuze == "2":
        artikel_id = input("Voer het artikel ID in: ")
        return {"type": "artikel", "waarde": int(artikel_id)}
    elif keuze == "3":
        categorie = input("Voer de productcategorie in: ")
        return {"type": "categorie", "waarde": categorie}
    else:
        return None  # Geen filter toegepast

# Filterfunctie voor omzetrapporten
def filter_omzetrapport(omzet_data, filter):
    if filter is None:
        return omzet_data
    if filter["type"] == "maand":
        return {maand: omzet for maand, omzet in omzet_data.items() if maand.startswith(filter["waarde"])}
    elif filter["type"] == "artikel":
        return {artikel_id: omzet for artikel_id, omzet in omzet_data.items() if artikel_id == filter["waarde"]}
    elif filter["type"] == "categorie":
        return {artikel_id: omzet for artikel_id, omzet in omzet_data.items() if artikel_id in filter["waarde"]}
    return omzet_data  # Geen resultaten als geen filtertype is gevonden
