from gui.interface import MixPanel

if __name__ == "__main__":
    app = MixPanel(ano 2025)
    app.run()
