def add_reverb(audio, intensity=0.5):
    # Eenvoudige reverb-implementatie
    return audio + audio.reverse().fade_in(intensity * 1000)
