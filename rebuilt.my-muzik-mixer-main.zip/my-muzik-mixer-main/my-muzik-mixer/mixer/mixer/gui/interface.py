import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QSlider

class MixPanel(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Muzik Mixer 2025")
        self.setGeometry(100, 100, 800, 600)
        self.init_ui()

    def init_ui(self):
        # Voeg knoppen en sliders toe
        play_button = QPushButton("Play", self)
        play_button.setGeometry(50, 500, 80, 40)
        play_button.clicked.connect(self.play_audio)

        volume_slider = QSlider(self)
        volume_slider.setGeometry(200, 500, 200, 40)

    def play_audio(self):
        # Logica voor afspelen
        print("Audio afspelen")

    def run(self):
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    panel = MixPanel()
    panel.run()
    sys.exit(app.exec_())
