from mixer.audio import load_audio, mix_tracks

def test_load_audio():
    track = load_audio("test.wav")
    assert track is not None

def test_mix_tracks():
    track1 = load_audio("test1.wav")
    track2 = load_audio("test2.wav")
    mixed = mix_tracks(track1, track2)
    assert len(mixed) == max(len(track1), len(track2))
