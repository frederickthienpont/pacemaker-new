from pydub import AudioSegment

def load_audio(file_path):
    return AudioSegment.from_file(file_path)

def mix_tracks(track1, track2):
    # Zorg dat beide tracks dezelfde lengte hebben
    if len(track1) > len(track2):
        track2 += AudioSegment.silent(duration=len(track1) - len(track2))
    else:
        track1 += AudioSegment.silent(duration=len(track2) - len(track1))
    return track1.overlay(track2)
