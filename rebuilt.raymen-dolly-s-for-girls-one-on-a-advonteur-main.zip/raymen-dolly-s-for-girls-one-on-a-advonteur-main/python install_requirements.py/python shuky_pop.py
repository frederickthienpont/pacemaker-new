
import pygame
import sys

# Initialisatie van pygame
pygame.init()

# Instellingen voor het scherm
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Shuky Pop Prototype')

# Kleuren
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Functie voor het tekenen van de pop
def draw_shuky(x, y):
    # Hoofd
    pygame.draw.circle(screen, RED, (x, y), 50)
    
    # Lichaam
    pygame.draw.rect(screen, BLUE, (x-25, y+50, 50, 100))
    
    # Armen
    pygame.draw.line(screen, BLACK, (x-25, y+50), (x-75, y+100), 5)  # Linker arm
    pygame.draw.line(screen, BLACK, (x+25, y+50), (x+75, y+100), 5)  # Rechter arm
    
    # Benen
    pygame.draw.line(screen, BLACK, (x-25, y+150), (x-50, y+200), 5)  # Linker been
    pygame.draw.line(screen, BLACK, (x+25, y+150), (x+50, y+200), 5)  # Rechter been

# Hoofdprogramma
def main():
    clock = pygame.time.Clock()

    # Beginpositie van de pop
    x = screen_width // 2
    y = screen_height // 3

    # Hoofdloop van het programma
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Verkrijg de huidige toetsenbordinvoer
        keys = pygame.key.get_pressed()

        # Beweging van de pop
        if keys[pygame.K_LEFT]:
            x -= 5  # Beweeg naar links
        if keys[pygame.K_RIGHT]:
            x += 5  # Beweeg naar rechts
        if keys[pygame.K_UP]:
            y -= 5  # Beweeg omhoog
        if keys[pygame.K_DOWN]:
            y += 5  # Beweeg omlaag

        # Zorg ervoor dat de pop binnen het scherm blijft
        x = max(50, min(x, screen_width - 50))
        y = max(50, min(y, screen_height - 50))

        # Scherm vullen met wit
        screen.fill(WHITE)
        
        # Teken de pop
        draw_shuky(x, y)
        
        # Werk het scherm bij
        pygame.display.flip()

        #
