import os
import shutil
import zipfile
import sys

class SimpleInstaller:
    def __init__(self, source_path, install_path):
        self.source_path = source_path
        self.install_path = install_path

    def check_permissions(self):
        """Check if the script has write permissions to the install directory."""
        if not os.access(self.install_path, os.W_OK):
            print(f"Error: You do not have write permission to the directory '{self.install_path}'.")
            sys.exit(1)

    def create_install_directory(self):
        """Create the target installation directory if it doesn't exist."""
        if not os.path.exists(self.install_path):
            print(f"Creating installation directory: {self.install_path}")
            os.makedirs(self.install_path)

    def extract_files(self):
        """Extract files from a ZIP archive (if applicable)."""
        if self.source_path.endswith(".zip"):
            print(f"Extracting files from {self.source_path}...")
            try:
                with zipfile.ZipFile(self.source_path, 'r') as zip_ref:
                    zip_ref.extractall(self.install_path)
                print(f"Files successfully extracted to {self.install_path}.")
            except Exception as e:
                print(f"Error extracting ZIP file: {e}")
                sys.exit(1)
        else:
            print(f"Source path is not a ZIP file: {self.source_path}")
            sys.exit(1)

    def copy_files(self):
        """Copy files from the source to the installation directory."""
        if os.path.isdir(self.source_path):
            print(f"Copying files from {self.source_path} to {self.install_path}...")
            try:
                for item in os.listdir(self.source_path):
                    s = os.path.join(self.source_path, item)
                    d = os.path.join(self.install_path, item)
                    if os.path.isdir(s):
                        shutil.copytree(s, d, dirs_exist_ok=True)
                    else:
                        shutil.copy2(s, d)
                print(f"Files successfully copied to {self.install_path}.")
            except Exception as e:
                print(f"Error copying files: {e}")
                sys.exit(1)
        else:
            print("Error: Source path is not a valid directory.")
            sys.exit(1)

    def run_installation(self):
        """Run the entire installation process."""
        print(f"Starting installation from {self.source_path} to {self.install_path}...")
        self.check_permissions()
        self.create_install_directory()
        self.extract_files()
        self.copy_files()
        print("Installation completed successfully!")

# Example usage
def main():
    source_path = input("Enter the path of the source files or archive (e.g., 'installer.zip'): ")
    install_path = input("Enter the target installation directory: ")

    installer = SimpleInstaller(source_path, install_path)
    installer.run_installation()

if __name__ == "__main__":
    main()
