from boxer import Boxer
from database import get_conn

def simuleer_wedstrijd(boxer1_id, boxer2_id):
    boxer1 = Boxer.get_by_id(boxer1_id)
    boxer2 = Boxer.get_by_id(boxer2_id)

    if not boxer1 or not boxer2:
        print("Fout: Een of beide boksers bestaan niet.")
        return

    winnaar = boxer1 if random.random() < (boxer1.kansen_berekenen(boxer2) / 100) else boxer2

    if winnaar == boxer1:
        boxer1.win_count += 1
        boxer2.loss_count += 1
    else:
        boxer2.win_count += 1
        boxer1.loss_count += 1

    boxer1.update()
    boxer2.update()

    print(f"De winnaar is {winnaar.naam}")
