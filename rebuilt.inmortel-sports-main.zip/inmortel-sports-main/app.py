from flask import Flask, render_template, request
from database import init_db, voeg_bokser_toe, voeg_event_toe, voeg_betaling_toe
from wedstrijd import simuleer_wedstrijd

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/wedstrijd', methods=['POST'])
def wedstrijd():
    boxer1_id = int(request.form['boxer1_id'])
    boxer2_id = int(request.form['boxer2_id'])
    simuleer_wedstrijd(boxer1_id, boxer2_id)
    return render_template('wedstrijd_resultaat.html')

if __name__ == '__main__':
    init_db()  # Zorg ervoor dat de database goed is ingesteld
    app.run(debug=True)
