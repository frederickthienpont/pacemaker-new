import random
from database import get_conn

class Boxer:
    def __init__(self, id, naam, gewichtsklasse, land, win_count=0, loss_count=0):
        self.id = id
        self.naam = naam
        self.gewichtsklasse = gewichtsklasse
        self.land = land
        self.win_count = win_count
        self.loss_count = loss_count

    def win_loss_ratio(self):
        total = self.win_count + self.loss_count
        if total == 0:
            return 0
        return self.win_count / total

    def kansen_berekenen(self, tegenstander):
        self_ratio = self.win_loss_ratio()
        tegenstander_ratio = tegenstander.win_loss_ratio()

        if self_ratio + tegenstander_ratio == 0:
            return 50  # als beide geen ervaring hebben, is het een gelijke kans
        kansen = (self_ratio / (self_ratio + tegenstander_ratio)) * 100
        return min(max(kansen, 10), 90)  # Houd de kansen binnen redelijke grenzen

    @staticmethod
    def get_by_id(id):
        conn = get_conn()
        c = conn.cursor()
        c.execute('SELECT * FROM boksers WHERE id = ?', (id,))
        data = c.fetchone()
        conn.close()

        if data:
            return Boxer(id=data[0], naam=data[1], gewichtsklasse=data[2], land=data[3], win_count=data[4], loss_count=data[5])
        return None

    def update(self):
        conn = get_conn()
        c = conn.cursor()
        c.execute('''UPDATE boksers
                     SET win_count = ?, loss_count = ?
                     WHERE id = ?''', (self.win_count, self.loss_count, self.id))
        conn.commit()
        conn.close()
