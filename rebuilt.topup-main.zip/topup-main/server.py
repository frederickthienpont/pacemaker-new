python server.py
