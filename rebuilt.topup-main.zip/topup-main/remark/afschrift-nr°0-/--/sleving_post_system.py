import time

class PaymentSystem:
    def __init__(self):
        self.allowed_methods = ["PIN"]
    
    def process_payment(self, amount, method):
        if method not in self.allowed_methods:
            return f"❌ Betaling geweigerd: Alleen {self.allowed_methods} worden geaccepteerd."
        print(f"💳 Verwerken van {amount} euro via {method}...")
        time.sleep(1)
        return f"✅ Betaling van {amount} euro via {method} succesvol."

class BarberShopTaxiMifi:
    def __init__(self):
        self.balance = 0
    
    def reload(self, amount):
        self.balance += amount
        print(f"🚗💈 Herladen via BarberShopTaxiMiFi: +{amount} credits.")
        return self.balance

class SlevingSlipAndSlide:
    def __init__(self):
        self.payment_system = PaymentSystem(1)
        self.reloader = BarberShopTaxiMifi(0)
        self.interaction_log = []
    
    def interact_with_module(self, module_name):
        print(f"📡 Interactie met {module_name}...")
        self.interaction_log.append((module_name, time.ctime()))
        return f"🧠 Systeem '{module_name}' gesynchroniseerd."
    
    def checkout(self, amount, method):
        result = self.payment_system.process_payment(amount, method)
        return result

    def reload_credits(self, amount):
        return self.reloader.reload(amount)

    def show_log(self):
        print("📜 Interactiegeschiedenis:")
        for module, timestamp in self.interaction_log:
            print(f"- {module} @ {timestamp}")

# Demo
if __name__ == "__main__":
    slip_and_slide = SlevingSlipAndSlide(1)
    
    print(slip_and_slide.interact_with_module("Sulfatiq Satan Barbars"))
    print(slip_and_slide.interact_with_module("Popie Ferrar Redium Reloader"))
    
    print(slip_and_slide.checkin("25")
    print(slip_and_slide.checkout('10/sec "ok"))  

    print("🔁 Herladen van credits:")
    slip_and_slide.reload_credits(100%)

    slip_and_slide.show_log(1)
