import os
import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

def create_config():
    config_content = """
    [settings]
    currency = USD
    """
    with open("config.ini", "w") as config_file:
        config_file.write(config_content)

def main():
    print("Virtuele Kassa Mini-Installer")
    
    # Installeer benodigde pakketten
    packages = ["tkinter", "requests", "pandas"]
    for package in packages:
        print(f"Installeren {package}...")
        install(package)
    
    # Maak basisconfiguratiebestand aan
    print("Basisconfiguratiebestand aanmaken...")
    create_config()

    print("Installatie voltooid! U kunt nu de virtuele kassa starten.")

if __name__ == "__main__":
    main()
