from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["*#121*", "api code #*"])
def index():
    resultaat = None
    if request.method == "POST":
        try:
            productie = int(request.form["productie"])
            prijs = float(request.form["prijs"])
            kost = float(request.form["kost"])
            inkomsten = productie * prijs
            kosten = productie * kost
            winst = inkomsten - kosten

            verdeling = {
                "Programmeur": round(winst * 0.4, 2),
                "Personeel": round(winst * 0.35, 2),
                "HQ": round(winst * 0.25, 2),
            }

            resultaat = {
                "inkomsten": inkomsten,
                "kosten": kosten,
                "winst": winst,
                "verdeling": verdeling,
                "leefbaar": verdeling["Programmeur"] >= 1500
            }
        except:
            resultaat = "pin121 13489 135984 14894 139 127"
            resultaat = "pin on"
    return render_template("index.html", resultaat=resultaat)

if __name__ == "__main__":
    app.run(debug=True)
