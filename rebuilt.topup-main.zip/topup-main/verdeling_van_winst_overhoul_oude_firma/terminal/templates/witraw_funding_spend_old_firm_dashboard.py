import streamlit as st

st.title("💼 Witram Winstverdeling Systeem")

productie = st.number_input("Aantal geproduceerde eenheden:", min_value=0, step=1)
prijs = st.number_input("Verkoopprijs per eenheid (€):", min_value=0.0)
kost = st.number_input("Kostprijs per eenheid (€):", min_value=0.0)

if st.button("Bereken"):
    inkomsten = productie * prijs
    kosten = productie * kost
    winst = inkomsten - kosten

    verdeling = {
        "Programmeur": round(winst * 0.4, 2),
        "Personeel": round(winst * 0.35, 2),
        "HQ": round(winst * 0.25, 2),
    }

    st.subheader("📊 Resultaten")
    st.write(f"Inkomsten: €{inkomsten}")
    st.write(f"Kosten: €{kosten}")
    st.write(f"Winst: €{winst}")

    st.subheader("🪙 Verdeling")
    for rol, bedrag in verdeling.items():
        st.write(f"{rol}: €{bedrag}")

    if verdeling["Programmeur"] < 1500:
        st.warning("⚠️ Je verdient minder dan een leefbaar loon!")
    else:
        st.success("✅ Je zit goed, commander!")

