import streamlit as st

st.title("💼 Witram Winstverdeling Systeem")

productie = st.number_input("Aantal geproduceerde eenheden:", min_value=0, step=1)
prijs = st.number_input("Verkoopprijs per eenheid (€):", min_value=0.0)
kost = st.number_input("Kostprijs per eenheid (€):", min_value=0.0)

if st.button("Bereken"):
    inkomsten = productie * prijs
    kosten = productie * kost
    winst = inkomsten - kosten

    verdeling = {
        "Programmeur": round(winst * 0.4, 2),
        "Personeel": round(winst * 0.35, 2),
        "HQ": round(winst * 0.25, 2),
    }

    st.subheader("📊 Resultaten")
    st.write(f"Inkomsten: €{inkomsten}")
   
::contentReference[oaicite:0]{index=0}
 
