def main():
    print("💼 Witram Productie Verdelingsysteem 💼")
    
    productie_aantal = int(input("Aantal geproduceerde eenheden: "))
    prijs_per_eenheid = float(input("Verkoopprijs per eenheid (€): "))
    kost_per_eenheid = float(input("Kostprijs per eenheid (€): "))

    totale_inkomsten = productie_aantal * prijs_per_eenheid
    totale_kosten = productie_aantal * kost_per_eenheid
    winst = totale_inkomsten - totale_kosten

    verdeling = {
        'Programmeur': 0.40,
        'Personeel': 0.35,
        'HQ': 0.25
    }

    print("\n📊 Financieel Overzicht 📊")
    print(f"Inkomsten: €{totale_inkomsten:.2f}")
    print(f"Kosten: €{totale_kosten:.2f}")
    print(f"Winst: €{winst:.2f}")

    print("\n🪙 Winstverdeling 🪙")
    for rol, percentage in verdeling.items():
        aandeel = winst * percentage
        print(f"{rol}: €{aandeel:.2f}")

    leefbaar_loon = 1500
    programmeur_aandeel = winst * verdeling['Programmeur']
    if programmeur_aandeel < leefbaar_loon:
        print("\n⚠️ Je verdient minder dan een leefbaar loon!")
    else:
        print("\n✅ Alles onder controle, programmeur!")

if __name__ == "__main__":
    main()
