const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Fake storage (you'd use a DB in real life)
let userSettings = {};

// Save setup data
app.post('/api/setup', (req, res) => {
  const { username, settings } = req.body;
  if (!username || !settings) {
    return res.status(400).json({ error: 'Missing fields' });
  }
  userSettings[username] = settings;
  return res.json({ message: 'Setup saved!' });
});

// View saved settings (for testing)
app.get('/api/setup/:username', (req, res) => {
  const settings = userSettings[req.params.username];
  if (!settings) {
    return res.status(404).json({ error: 'User not found' });
  }
  return res.json({ settings });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
