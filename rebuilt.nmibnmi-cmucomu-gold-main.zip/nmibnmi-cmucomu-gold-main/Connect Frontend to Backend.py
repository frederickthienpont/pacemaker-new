// Replace alert in step7 with:
button.onclick = function () {
  const settings = {
    accessControl: document.querySelector('select').value,
    droneScan: document.querySelector('#step4 input[type=checkbox]').checked,
    encryption: document.querySelector('#step6 input[type=checkbox]').checked,
    // ...you can add more fields as needed
  };
  const username = document.getElementById('username').value;

  fetch('/api/setup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, settings })
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message || 'Setup complete!');
  });
};
