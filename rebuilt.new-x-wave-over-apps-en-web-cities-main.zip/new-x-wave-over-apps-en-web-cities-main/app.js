let scene, camera, renderer;

function init() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight * 0.9);
  document.getElementById('viewer').appendChild(renderer.domElement);

  const light = new THREE.PointLight(0xffffff);
  light.position.set(10, 10, 10);
  scene.add(light);

  camera.position.z = 5;
  animate();
}

function addBlock(x = 0, y = 0, z = 0) {
  const geometry = new THREE.BoxGeometry();
  const material = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
  const cube = new THREE.Mesh(geometry, material);
  cube.position.set(x, y, z);
  scene.add(cube);
}

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}

init();
