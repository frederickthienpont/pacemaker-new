const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

app.post('/save', (req, res) => {
  fs.writeFileSync('blocks.json', JSON.stringify(req.body));
  res.send({ status: 'saved' });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
