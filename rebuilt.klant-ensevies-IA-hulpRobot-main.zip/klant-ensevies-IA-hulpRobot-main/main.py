from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from utils import get_ai_response
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

@app.route("/sms", methods=["POST"])
def sms_reply():
    message_body = request.form["Body"]
    reply = get_ai_response(message_body)

    resp = MessagingResponse()
    resp.message(reply)
    return str(resp)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
