Write-Host "🚀 AI SMS Bot Installer gestart..." -ForegroundColor Cyan

# Check Python
if (!(Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "⚠️ Python is niet geïnstalleerd. Installeer Python 3.10+ eerst." -ForegroundColor Red
    exit
}

# Maak virtuele omgeving
python -m venv venv
.\venv\Scripts\Activate.ps1

# Installeer vereisten
pip install -r requirements.txt

# .env setup
if (!(Test-Path ".env")) {
    Write-Host "`n🔐 Laten we je API sleutels instellen..."
    $openai = Read-Host "Voer je OpenAI API key in"
    $twilio_sid = Read-Host "Voer je Twilio Account SID in"
    $twilio_token = Read-Host "Voer je Twilio Auth Token in"

    @"
OPENAI_API_KEY=$openai
TWILIO_ACCOUNT_SID=$twilio_sid
TWILIO_AUTH_TOKEN=$twilio_token
"@ | Set-Content -Path ".env"
    Write-Host "✅ .env bestand aangemaakt."
}

Write-Host "`n✅ Installatie voltooid. Start de app met: `npython app/main.py" -ForegroundColor Green
