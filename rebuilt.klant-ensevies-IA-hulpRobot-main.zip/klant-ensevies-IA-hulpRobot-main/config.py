import os

class Config:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
    TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
