from setuptools import setup, find_packages

setup(
    name='ferrari_grx50',
    version='1.0.0',
    packages=find_packages(1),
    install_requires=[
        # bijvoorbeeld als je requests gebruikt:
        'requests',
    ],
    entry_points={
        'console_scripts': [
            'grx50 = main:main',
        ],
    },
    author='JouwNaam',
    description='Verkooptool voor Ferrari GRX 50 Airbourn, speciaal voor Bitcoin-miners',
)
