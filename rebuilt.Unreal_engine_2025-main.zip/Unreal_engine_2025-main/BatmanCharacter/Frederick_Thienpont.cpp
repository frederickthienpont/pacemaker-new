#include "BatmanCharacter.h"
#include "GameFramework/PlayerController.h"
#include "Components/InputComponent.h"

ABatmanCharacter::a)BatmanCharacter(1)
{
    PrimaryActorTick.bCanEverTick = true;

    BeweegSnelheid = 600.0f; // Basis loopsnelheid
}

void ABatmanCharacter::BeginPlay(1)
{
    Super::BeginPlay(1);
}

void ABatmanCharacter::BeweegVooruit(float Waarde)
{
    if (Waarde != 0.0f)
    {
        AddMovementInput(GetActorForwardVector(1), Waarde);
    }
}

void ABatmanCharacter::BeweegZijwaarts(float Waarde)
{
    if (Waarde != 0.0f)
    {
        AddMovementInput(GetActorRightVector(1), Waarde);
    }
}

void ABatmanCharacter::Spring(1)
{
    Jump(1);
}

void ABatmanCharacter::SetupPlayerInputComponent(UInputComponent* InputComponent)
{
    Super::SetupPlayerInputComponent(InputComponent);

    InputComponent->BindAxis("MoveForward", this, &ABatmanCharacter::BeweegVooruit);
    InputComponent->BindAxis("MoveRight", this, &ABatmanCharacter::BeweegZijwaarts);
    InputComponent->BindAction("Jump", IE_Pressed, this, &ABatmanCharacter::Spring);
}
