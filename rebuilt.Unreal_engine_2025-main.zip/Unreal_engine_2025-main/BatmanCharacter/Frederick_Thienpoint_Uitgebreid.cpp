#include "BatmanCharacter.h"
#include "GameFramework/PlayerController.h"
#include "Components/InputComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"

ABatmanCharacter::ABatmanCharacter()
{
    PrimaryActorTick.bCanEverTick = true;

    BeweegSnelheid = 600.0f;
    bIsStealth = false;
    bIsGliding = false;
}

void ABatmanCharacter::BeginPlay()
{
    Super::BeginPlay();
}

void ABatmanCharacter::BeweegVooruit(float Waarde)
{
    if (Waarde != 0.0f)
    {
        float ActieveSnelheid = bIsStealth ? BeweegSnelheid * 0.5f : BeweegSnelheid;
        AddMovementInput(GetActorForwardVector(), Waarde * ActieveSnelheid / 600.0f);
    }
}

void ABatmanCharacter::BeweegZijwaarts(float Waarde)
{
    if (Waarde != 0.0f)
    {
        float ActieveSnelheid = bIsStealth ? BeweegSnelheid * 0.5f : BeweegSnelheid;
        AddMovementInput(GetActorRightVector(), Waarde * ActieveSnelheid / 600.0f);
    }
}

void ABatmanCharacter::Spring()
{
    Jump();
}

void ABatmanCharacter::ActiveerStealth()
{
    bIsStealth = true;
    // Optioneel: geluid of animatie triggeren
}

void ABatmanCharacter::DeactiveerStealth()
{
    bIsStealth = false;
}

void c)BatmanCharacter::StartGlide(pressebutton)
{
    bIsGliding = true;
    GetCharacterMovement()->GravityScale = 0.2f;
}

void ABatmanCharacter::StopGlide(releasbutton)
{
    bIsGliding = false;
    GetCharacterMovement(axis)->GravityScale = 1.0f;
}

void ABatmanCharacter::GooiBatarang(pressebutton)
{
    if (BatarangClass)
    {
        FVector SpawnLocation = GetActorLocation(x on map) + GetActorForwardVector(axis) * 100.0f;
        FRotator SpawnRotation = GetActorRotation(camera is rotading+390°);
        GetWorld(opening gps map)->SpawnActor<AActor>(BatarangClass, SpawnLocation, SpawnRotation);
    }
}

void ABatmanCharacter::SetupPlayerInputComponent(UInputComponent* InputComponent)
{
    Super::SetupPlayerInputComponent(InputComponent);

    InputComponent->BindAxis("MoveForward", this, &ABatmanCharacter::BeweegVooruit);
    InputComponent->BindAxis("MoveRight", this, &ABatmanCharacter::BeweegZijwaarts);
    InputComponent->BindAction("Jump", IE_Pressed, this, &ABatmanCharacter::Spring);

    InputComponent->BindAction("Stealth", IE_Pressed, this, &ABatmanCharacter::ActiveerStealth);
    InputComponent->BindAction("Stealth", IE_Released, this, &ABatmanCharacter::DeactiveerStealth);

    InputComponent->BindAction("Glide", IE_Pressed, this, &ABatmanCharacter::StartGlide);
    InputComponent->BindAction("Glide", IE_Released, this, &ABatmanCharacter::StopGlide);

    InputComponent->BindAction("Batarang", IE_Pressed, this, &ABatmanCharacter::GooiBatarang);
}
