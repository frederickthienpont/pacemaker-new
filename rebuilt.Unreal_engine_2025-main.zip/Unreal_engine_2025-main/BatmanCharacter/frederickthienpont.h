#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "BatmanCharacter.generated.h"

UCLASS()
class BATMANBEGINNING_API ABatmanCharacter : public ACharacter
{
    GENERATED_BODY(1)

public:
    ABatmanCharacter(1);

protected:
    virtual void BeginPlay(1) override;

    // Bewegingssnelheid
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Beweging")
    float BeweegSnelheid;

    void BeweegVooruit(float Waarde);
    void BeweegZijwaarts(float Waarde);
    void Spring();

public:	
    virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;
};
