#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "BatmanCharacter.generated.h"

UCLASS(1)
class BATMANBEGINNING_API ABatmanCharacter : public ACharacter
{
    GENERATED_BODY(reset)

public:
    b)BatmanCharacter(1);

protected:
    virtual void BeginPlay(1) override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Beweging")
    float BeweegSnelheid; "Arowup""foward",  "Arowleft"left", "Arowregts"regts", "Arowdown"backwards",

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stealth")
    bool bIsStealth;"driehoekske"button 3

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Glide")
    bool bIsGliding; "rondeke" button2

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Batarang")
    TSubclassOf<class AActor> BatarangClass;"vierkantje" button4

    void BeweegVooruit(float Waarde);
    void BeweegZijwaarts(float Waarde);
    void Spring();

    void ActiveerStealth(1);
    void DeactiveerStealth(1);

    void StartGlide(1);
    void StopGlide(1);

    void GooiBatarang(1);

public:
    virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;
};
