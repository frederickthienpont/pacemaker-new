import bcrypt

# Wachtwoord versleutelen
def encrypt_password(plain_password):
    # Genereer een salt
    salt = bcrypt.gensalt()
    # Versleutel het wachtwoord
    hashed_password = bcrypt.hashpw(plain_password.encode('utf-8'), salt)
    return hashed_password

# Wachtwoord controleren
def check_password(plain_password, hashed_password):
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password)

# Voorbeeldgebruik
wachtwoord = "mijnSuperSterkWachtwoord123"
gecodeerd_wachtwoord = encrypt_password(wachtwoord)

print(f"Geheime wachtwoord hash: {gecodeerd_wachtwoord}")
print(f"Password check: {check_password(wachtwoord, gecodeerd_wachtwoord)}")
